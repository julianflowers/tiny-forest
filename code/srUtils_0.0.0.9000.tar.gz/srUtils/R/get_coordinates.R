## function to extract location coordinates

#' Get lat-longs
#'
#' @param text
#'
#' @return matrix
#' @export
#'
#' @examples
#' get_coordinates(text$text)
#'


get_coordinates <- function(text){

  require(tibble)
  require(dplyr)
  require(stringr)
  require(tidyr)

  colon <- "([NSEW])(\\d{1,2}):(\\d{1,2}):(\\d{1,2})"
  decimal <- "(\\d{1,2})\\.(\\d{1,2}).?(◦|°).?([NSEW])"
  polar_lat <- "(\\d{1,2})(◦|°|)\\s?(\\d{1,2})\\D*([NS])"
  polar_long <- "(\\d{1,2})(◦|°|)\\s?(\\d{1,2})\\D*([EW])"
  e_n <- "(\\d{4,6})\\D?([NS]).*(\\d{4,6})\\D?([EW])"

  colon_pattern <- str_match_all(text, colon) |>
    enframe()
  decimal_pattern <- str_match_all(text, decimal) |>
    enframe()

  polar_lat_pattern <- str_match_all(text, polar_lat) |>
    enframe()

  polar_long_pattern <- str_match_all(text, polar_long) |>
    enframe()

  e_n_pattern <- str_match_all(text, e_n) |>
    enframe()

  out <- bind_rows(c = colon_pattern, d = decimal_pattern, lat = polar_lat_pattern,
                          long = polar_long_pattern, en = e_n_pattern)
  out
}


get_elevation <- function(text){

  require(tibble)
  require(dplyr)
  require(stringr)
  require(tidyr)

  el_pattern <- "(elevation of|a.s.l|above sea level)?\\s?(\\d{1,})\\s([m]?)\\s(elevation|a.s.l|above sea level)"

  elevations <- str_match_all(text, el_pattern) |>
    enframe()

  return(elevations)

}


get_chemical <- function(text){

  require(tibble)
  require(dplyr)
  require(stringr)
  require(tidyr)

  chemical <- "N2O|NO2|NO|CO|CO2|[Cc]arbon|nitrog*|.*flux|ghg|greenhouse.*"
  chem_pattern <- str_match_all(text, chemical) |>
    enframe()

  return(chem_pattern)

}

get_air_temperature <- function(text){

  require(tibble)
  require(dplyr)
  require(stringr)
  require(tidyr)

  at_pattern <- "(\\d{1,}\\.?\\d{1,2}?)\\D*(°|◦|degrees)(.?[C])\\D*"
  at_pattern <- str_match_all(text, at_pattern) |>
    enframe()

}

path <- here::here("my_corpus")

files <- list.files(path, "pdf$", full.names = TRUE)

texts <- purrr::map_dfr(files, readtext::readtext)

texts[1:2,]
str(texts)

gc <- get_chemical(texts$text[5])

gc

gc |>
  unnest("value") |>
  distinct()

